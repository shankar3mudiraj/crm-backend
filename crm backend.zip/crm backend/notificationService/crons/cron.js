/*
we will take of node-cron to  repeat some lines of code at regular intervals
*/
const cron=require("node-cron");
const Notification=require("../models/notification.model")
const constants=require("../utils/constant")
const emailservice=require("../notifier/emailService")

//for everyy 30 second send the notfications for each requests
cron.schedule('*/30 * * * * *', async ()=>{
/**
 * i need to send the emails
 * 1.get the list of all notifications to be sent
 * 2. sendemail for each notification
 */

const notifications=await Notification.find({sentStatus :constants.sentStatus.unsent})



})