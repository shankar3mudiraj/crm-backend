module.exports ={
  sentStatus :{
    sent :"SENT",
    unsent : "UN_SENT"
  }
}