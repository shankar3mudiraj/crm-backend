module.exports = {
   DB_NAME : "notification_app",
   DB_URL : "mongodb://localhost/notification_app"
}