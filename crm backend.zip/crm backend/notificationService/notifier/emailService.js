/**
 * this file will have the logic to send the emails
 */

const nodemailer =require("nodemailer");






module.exports = nodemailer.createTransport({
  port : 465,
  host : "smtp.gmail.com",
  auth : {
      user : 'vish007dev@gmail.com',
      pass :'Welcome@07'
  },
  secure : true
});

























/**
 * i neee to setup the node mailer for send the emails
 * smptp host details
 * credentials if needed 
 */
 
// //**
// //  * transporter is used to send the emails
// //  */

// const mailObj={
//   from:'salmanKhan@bollywood.com',
//   to:'shankarmudhirajccc@333.com',
//   subject:'very important message',
//   text:'theres nothing important than time in life'
// };
// transporter.sendMail(mailObj,(err,info)=>{
//   if(err){
//     console.log(err)
//   }else{
//     console.log(info);
//   }
// })