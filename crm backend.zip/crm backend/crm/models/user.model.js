//this file will hold the schema for the user resource

const mongoose =require("mongoose");

userSchema=new mongoose.Schema({


//name, userid,password ,email ,createdat , updatedat
//userType [ADMIN | ENGINEER | CUSTOMER],userStatus[PENDING | APPROVED | REJECTED]

name :
{
  type : String ,
  required : true,
  
},
userId :
{
  type : String,
  required : true,
  unique : true
},
Password :
{
  type : String,
  required :true
},
email:
 {
    type  : String ,
    required : true,
    lowercase : true,
    minlength : 10,
    unique : true
 },
 createdAt : 
 {
    type : Date,
    immutable : true,
    default : ()=>{
      return Date.now(); 
    }
 },
 userType :
 {
   type : String,
   required : true,
   default : "CUSTOMER"
 },
 userStatus : {
    type : String,
    required : true,
    default : "PENDING"
 },
 ticketsCreated : {
   type : [mongoose.SchemaTypes.ObjectId],
   ref: "Ticket"
 },
 ticketsAssigned :
 {
   type : [mongoose.SchemaTypes.ObjectId],
   ref : "Ticket"
  
 }

});

module.exports=mongoose.model("User",userSchema);