const express=require("express");
const serverconfig= require("./configs/server.config"); 
const mongoose=require("mongoose");
const dbConfig=require("./configs/db.config");
const bodyparser=require("body-parser");
const User =require("./models/user.model");
const { userTypes } = require("./utils/constants");
const bcrypt=require("bcryptjs");

const app=express();
app.use(bodyparser.json());
app.use(bodyparser.urlencoded({extended:true}));

//setup the mongodb Connection and Create the ADMIN user


mongoose.connect(dbConfig.DB_URL,()=>{
   console.log("MongoDB connected");
   //Initialization
   init();
})
 async function init(){

  var user =await User.findOne({userId : "admin"});
 if(user){
   return;
 }
 else{

//create the admin user
const user =await User.create({

  name : "vish",
  userId : "admin",
  email : "kasnanva3@gmail.com",
  userType : "ADMIN",
  Password : bcrypt.hashSync("welcome00123",8),
  userStatus:"APPROVED"
})
console.log("admin user is created");
}
 }
require('./routes/user.routes')(app);
require('./routes/auth.routes')(app);
require('./routes/ticket.routes')(app);

app.listen(serverconfig.PORT,()=>{
  console.log("application has started on the port",serverconfig.PORT);
})



