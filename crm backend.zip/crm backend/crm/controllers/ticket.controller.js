const Ticket=require("../models/ticket.model")
const User=require("../models/user.model");
const { userStatus } = require("../utils/constants");
const constants=require("../utils/constants")
const objectConverter=require("../utils/objectConverter");
/*
create a ticket
v1- Any one able to create the ticket
*/

exports.createTicket=async (req,res)=>
{
  //logic to create the ticket

const ticketObj={
 title : req.body.title,
 description : req.body.description,
 ticketPriority : req.body.ticketPriority
}
/*
if any engineer is available
*/
try{
const engineer = await User.findOne({
  userType : constants.userTypes.engineer,
  userStatus : constants.userStatus.approved
});

if(engineer){
ticketObj.assignee=engineer.userId;
}

  const ticket= await  Ticket.create(ticketObj);

  /*
  *.1 Ticket is Created now
    2 we should update the customer and engineer document 
  */
 /*
 Find out the customer
 */
   if(ticket){
     //console.log(ticket);
     const user=await User.findOne({
       userId: req.userId
     })
     if(user!=null){
     user.ticketsCreated.push(ticket. _id);
     await user.save();
     }

   // Find the engineer
   engineer.ticketsAssigned.push(ticket. _id);
   await engineer.save();

  return res.status(201).send(objectConverter.ticketResponse(ticket));

    }
}
catch(err){
  console.log(err);
  return res.status(500).send({
    message : "some internal error                                                                                                                        "
  })
}
}
/**
 * API to fetch all the tickets
 * 
 * Allow the user to filter based on state
 * 
 * TODO HW : Extension :
 * Using query param, allow the users to
 * filter the list of tickets based on status
 * 
 * Depending on the user I need to return differnt list of tickets :
 * 
 * 1. ADMIN - Return all tickets
 * 2. ENGINEER - All the tickets, either created or assigned to him/her
 * 3. CUSTOMER - All the tickets created by him
 */
 exports.getAllTickets = async (req, res) => {
  /**
   * I want to get the list of all the tickets
   */
  console.log(req.userId);
  const queryObj = {};
  if (req.query.status != undefined) {
      queryObj.status = req.query.status;
  }

  const user = await User.findOne({ userId: req.userId });
  if (user.userType == constants.userTypes.admin) {
      //Return all the tickets
      // No need to change anything in the query object
  } else if (user.userType == constants.userTypes.customer) {

      if (user.ticketsCreated == null || user.ticketsCreated.length == 0) {
          return res.status(200).send({
              message: "No tickets created by you !!!"
          })
      }

      queryObj._id = {
          $in: user.ticketsCreated // array of ticket ids
      }

  }else{

      /**
       * 
       * Assignment  :
       * 
       * Approach 1 :  $or ---
       * 
       * Approach 2 : in the in clause put both the lists
       *     ticketsCreated
       *     ticketsAssigned
       */
      //User is of type engineer
      queryObj._id = {
          $in: user.ticketsCreated // array of ticket ids
      };
      // All the tickets where I am the assignee
      queryObj.assignee = req.userId
  }
  const tickets = await Ticket.find(queryObj);
res.status(200).send(objectConverter.ticketListResponse(tickets))

}
exports.getOneTicket=async(req,res)=>{
  const ticket=await Ticket.findOne({
    _id:req.params.id
  })
  console.log(ticket);
  res.status(200).send(objectConverter.ticketListResponse(ticket))

}

/*
write a controller to update the ticket
*/
exports.updateTicket= async (req,res)=>{

  //check if the ticket exists

  const ticket=await Ticket.findOne({_id:req.params.id});

  if(ticket==null){
 return res.status(200).send({
    message:"ticket doesn't exist"
  })
  }
  //only ticket owner shour update the ticket

  const user=User.findOne({userId:req.userId})
  //console.log(req.params.id);
  if(!user.ticketsCreated.includes(req.params.id)){
    return res.status(403).send({
      message :"only owner of the ticket should be allowed to update the ticket"
    })
  }
  //updte the attributes of the saved the ticket
  console.log(ticket);

  ticket.title=req.body.title!=undefined?req.body.title:ticket.title;
  ticket.description=req.body.description!=undefined?req.body.description:ticket.description;
  ticket.ticketPriority=req.body.ticketPriority!=undefined?req.body.ticketPriority:ticket.ticketPriority;
  ticket.status=req.body.status!=undefined?req.body.status:ticket.status

  //save the changed ticket

  const updatedticket= await ticket.save();
  
  //return the updated ticket

  return res.status(200).send(objectConverter.ticketResponse(updatedticket))

}
  