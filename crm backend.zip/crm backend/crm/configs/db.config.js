module.exports = {
   DB_NAME : "crm_app",
   DB_URL : "mongodb://localhost/crm_app"
}