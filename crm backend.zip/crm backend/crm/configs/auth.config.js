module.exports={
  secret : "Shankar-Super-Secret"
}