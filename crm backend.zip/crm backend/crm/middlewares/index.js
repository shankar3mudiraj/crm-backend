const verifySignUp=require("./verifySignUp");
const authJwt=require("./authjwt");
module.exports={
  verifySignUp,
  authJwt
}