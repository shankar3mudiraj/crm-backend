// this file will contain the custom middleware
// for verifying the request body

const User=require("../models/user.model");
const constants=require("../utils/constants");

ValidateSignUpRequest= async (req,res,next)=>{
  //validate if user name exists
  if(!req.body.name){
    return res.status(400).send({
      message : "Failed ! user name is not provided"
    })
  }
  if(!req.body.userId){
    return res.status(400).send({
      message : "Failed ! userid is not provided"
    })
    }

    // validate if the user is already not present
   const user =await User.findOne({userId: req.body. userId});
   
   if(user!=null){
     return res.status(400).send({
       message : " Failed ! user already exists "
     })
   }

   //similar validation for all the other fields
   // email,password,userType
   
   
   if(!req.body.email){
     return res.status(400).send({
       message : " Failed ! email not provided"
     })   }

     // if email id is already existing 

       const email=await User.findOne({email : req.body.email});
       if(email!=null){
         return res.status(400).send({
           message:"Failed ! email already exists"
         })
       }

     if(!req.body.password){
       return res.status(400).send({
         message : "Failed ! password is not provided"
       })
     }

     // validation for user type
     const userType=req.body.userType;
     const userTypes=[constants.userTypes.customer,constants.userTypes.admin,constants.userTypes.engineer]
     if(userType && !userTypes.includes(userType)){
       return res.status(400).send({
         message : "Failed ! userType is not correctly provided"
       })
     }

   next();// give the control to the controllers
   
   //scope of improving the code
  }
  module.exports={
    ValidateSignUpRequest : ValidateSignUpRequest
  }
